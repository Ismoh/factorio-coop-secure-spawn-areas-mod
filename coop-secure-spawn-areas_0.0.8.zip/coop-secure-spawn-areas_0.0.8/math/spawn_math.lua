if not cssa_spawn_math then cssa_spawn_math = {} end

function cssa_spawn_math.get_new_path(player)
  local distance_between_spawns = settings.startup["distance-between-spawns"].value
  local distance_ok = false

  -- Calculate a new spawn randomly
  local new_spawn_position = {
    x = math.random(distance_between_spawns),
    y = math.random(distance_between_spawns)
  }

  
--[[ 
  https://www.onlinemathe.de/forum/Kreis-Punkte-auf-der-Linie-Berechnen
  https://mathematikalpha.de/wp-content/uploads/2016/12/09-Kreis.pdf seit 981

  y(φ)=yM+R⋅cos(φ)
  x(φ)=xM+R⋅sin(φ)
  φ = winkel -> 1-360, steps 1
 ]]

  local i = 0
  while i <= 100 do
    local distance_ok_each_force = false

    for key, entry in pairs(global.spawns) do
      local distance = math.sqrt(
        math.pow(entry.position.x - new_spawn_position.x, 2) +
        math.pow(entry.position.y - new_spawn_position.y, 2)
      )
      distance_ok_each_force = distance >= distance_between_spawns

      game.print("distance = " .. distance)
      game.print("distance_ok_each_force = " .. tostring(distance_ok_each_force))

      if not distance_ok_each_force then
        distance_ok = false
        game.print("distance_ok_each_force = " .. tostring(distance_ok_each_force))
        new_spawn_position.x = math.random(entry.position.x, distance_between_spawns)
        new_spawn_position.y = math.random(entry.position.y, distance_between_spawns)
      end
    end
    i = i + 1
  end

  table.insert(
    global.spawns,
    { force = player.force.name, position = new_spawn_position}
  )


  return new_spawn_position
end