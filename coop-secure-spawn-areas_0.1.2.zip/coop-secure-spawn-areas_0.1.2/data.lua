require "prototypes.sprites"
require "gui.gui-styles"