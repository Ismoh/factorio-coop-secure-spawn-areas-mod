# factorio-coop-secure-spawn-areas-mod
This is a factorio mod, which creates teams for factorio and also modify the map to have separated secure starting spawn areas.
